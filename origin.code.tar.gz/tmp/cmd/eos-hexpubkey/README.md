Print an EOS Public key as hex
------------------------------

This is a very stupid little program, uses the `eosapi` Go library to decode the Public key and print it out.

This is mainly because the `regproducer` call requires a hex version of the public key.  Go figure.
